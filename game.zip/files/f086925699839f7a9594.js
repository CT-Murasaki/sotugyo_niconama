function _typeof(o) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, _typeof(o); }
(function (f) {
  if ((typeof exports === "undefined" ? "undefined" : _typeof(exports)) === "object" && typeof module !== "undefined") {
    module.exports = f();
  } else if (typeof define === "function" && define.amd) {
    define([], f);
  } else {
    var g;
    if (typeof window !== "undefined") {
      g = window;
    } else if (typeof global !== "undefined") {
      g = global;
    } else if (typeof self !== "undefined") {
      g = self;
    } else {
      g = this;
    }
    g.aez_bundle_main = f();
  }
})(function () {
  var define, module, exports;
  return function () {
    function r(e, n, t) {
      function o(i, f) {
        if (!n[i]) {
          if (!e[i]) {
            var c = "function" == typeof require && require;
            if (!f && c) return c(i, !0);
            if (u) return u(i, !0);
            var a = new Error("Cannot find module '" + i + "'");
            throw a.code = "MODULE_NOT_FOUND", a;
          }
          var p = n[i] = {
            exports: {}
          };
          e[i][0].call(p.exports, function (r) {
            var n = e[i][1][r];
            return o(n || r);
          }, p, p.exports, r, e, n, t);
        }
        return n[i].exports;
      }
      for (var u = "function" == typeof require && require, i = 0; i < t.length; i++) o(t[i]);
      return o;
    }
    return r;
  }()({
    1: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      /**
       * コンバータ機能を提供するクラス。
       */
      var Converter = /** @class */function () {
        function Converter() {}
        /**
         * エンティティをホバー可能に変換する。
         */
        Converter.asHoverable = function (e, opts) {
          var hoverableE = e;
          hoverableE.hoverable = true;
          hoverableE.touchable = true;
          hoverableE.hovered = hoverableE.hovered || new g.Trigger();
          hoverableE.unhovered = hoverableE.unhovered || new g.Trigger();
          if (opts) {
            if (opts.cursor) hoverableE.cursor = opts.cursor;
          }
          return hoverableE;
        };
        /**
         * エンティティのホバーを解除する。
         */
        Converter.asUnhoverable = function (e) {
          var hoverableE = e;
          delete hoverableE.hoverable;
          if (hoverableE.hovered && !hoverableE.hovered.destroyed()) {
            hoverableE.hovered.destroy();
            delete hoverableE.hovered;
          }
          if (hoverableE.unhovered && !hoverableE.unhovered.destroyed()) {
            hoverableE.unhovered.fire();
            hoverableE.unhovered.destroy();
            delete hoverableE.unhovered;
          }
          return hoverableE;
        };
        return Converter;
      }();
      exports.Converter = Converter;
    }, {}],
    2: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      /**
       * ホバー機能を提供するプラグイン。
       */
      var HoverPlugin = /** @class */function () {
        function HoverPlugin(game, viewInfo, option) {
          if (option === void 0) {
            option = {};
          }
          this.game = game;
          this.view = viewInfo.view; // viewInfo が必ず渡ってくるため null にはならない
          this.beforeHover = null;
          this.operationTrigger = new g.Trigger();
          this._cursor = option.cursor || "pointer";
          this._showTooltip = !!option.showTooltip;
          this._latestHoveredPoint = null;
          this._getScale = viewInfo.getScale ? function () {
            return viewInfo.getScale();
          } : null;
          this._onMouseMove_bound = this._onMouseMove.bind(this);
          this._onMouseOut_bound = this._onMouseOut.bind(this);
        }
        HoverPlugin.isSupported = function () {
          return typeof document !== "undefined" && typeof document.addEventListener === "function";
        };
        HoverPlugin.prototype.start = function () {
          this.view.addEventListener("mousemove", this._onMouseMove_bound, false);
          this.view.addEventListener("mouseout", this._onMouseOut_bound, false);
          this.view.addEventListener("pointerout", this._onMouseOut_bound, false);
          return true;
        };
        HoverPlugin.prototype.stop = function () {
          this.view.removeEventListener("mousemove", this._onMouseMove_bound, false);
          this.view.removeEventListener("mouseout", this._onMouseOut_bound, false);
          this.view.removeEventListener("pointerout", this._onMouseOut_bound, false);
        };
        // 現在ホバーしている座標を返す。ホバーしていない時は null を返す。
        HoverPlugin.prototype.getLatestHoveredPoint = function () {
          return this._latestHoveredPoint;
        };
        HoverPlugin.prototype._onMouseMove = function (e) {
          var scene = this.game.scene();
          if (!scene) return;
          var rect = this.view.getBoundingClientRect();
          var positionX = rect.left + window.pageXOffset;
          var positionY = rect.top + window.pageYOffset;
          var offsetX = e.pageX - positionX;
          var offsetY = e.pageY - positionY;
          var scale = {
            x: 1,
            y: 1
          };
          if (this._getScale) {
            scale = this._getScale();
          }
          var point = {
            x: offsetX / scale.x,
            y: offsetY / scale.y
          };
          var target = scene.findPointSourceByPoint(point).target;
          if (target && target.hoverable) {
            this._latestHoveredPoint = point;
            if (target !== this.beforeHover) {
              if (this.beforeHover && this.beforeHover.hoverable) {
                this._onUnhovered(target);
              }
              this._onHovered(target);
            }
            this.beforeHover = target;
          } else if (this.beforeHover) {
            this._latestHoveredPoint = null;
            this._onUnhovered(this.beforeHover);
          }
        };
        HoverPlugin.prototype._onHovered = function (target) {
          if (target.hoverable) {
            this.view.style.cursor = target.cursor ? target.cursor : this._cursor;
            if (this._showTooltip && target.title) {
              this.view.setAttribute("title", target.title);
            }
            target.hovered.fire();
          }
        };
        HoverPlugin.prototype._onUnhovered = function (_target) {
          this.view.style.cursor = "auto";
          if (this.beforeHover && this.beforeHover.unhovered) {
            this.beforeHover.unhovered.fire();
            if (this._showTooltip) {
              this.view.removeAttribute("title");
            }
          }
          this.beforeHover = null;
        };
        HoverPlugin.prototype._onMouseOut = function () {
          if (this.beforeHover) this._onUnhovered(this.beforeHover);
        };
        return HoverPlugin;
      }();
      module.exports = HoverPlugin;
    }, {}],
    3: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      var Converter_1 = require("./Converter");
      exports.Converter = Converter_1.Converter;
      // HoverPlugin.ts で module.exports しているため、そのまま export すると使用側で型がおかしくなる。
      // 後方互換性のため module.exports は残しここでキャストしている。
      var plugin = require("./HoverPlugin");
      // eslint-disable-next-line @typescript-eslint/naming-convention
      var hoverPlugin = plugin;
      exports.HoverPlugin = hoverPlugin;
    }, {
      "./Converter": 1,
      "./HoverPlugin": 2
    }],
    4: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.ActionType = void 0;
      var ActionType;
      (function (ActionType) {
        ActionType[ActionType["Wait"] = 0] = "Wait";
        ActionType[ActionType["Call"] = 1] = "Call";
        ActionType[ActionType["TweenTo"] = 2] = "TweenTo";
        ActionType[ActionType["TweenBy"] = 3] = "TweenBy";
        ActionType[ActionType["TweenByMult"] = 4] = "TweenByMult";
        ActionType[ActionType["Cue"] = 5] = "Cue";
        ActionType[ActionType["Every"] = 6] = "Every";
      })(ActionType = exports.ActionType || (exports.ActionType = {}));
    }, {}],
    5: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.Easing = void 0;
      /**
       * Easing関数群。
       * 参考: http://gizma.com/easing/
       */
      var Easing;
      (function (Easing) {
        /**
         * 入力値をlinearした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */
        function linear(t, b, c, d) {
          return c * t / d + b;
        }
        Easing.linear = linear;
        /**
         * 入力値をeaseInQuadした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */
        function easeInQuad(t, b, c, d) {
          t /= d;
          return c * t * t + b;
        }
        Easing.easeInQuad = easeInQuad;
        /**
         * 入力値をeaseOutQuadした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */
        function easeOutQuad(t, b, c, d) {
          t /= d;
          return -c * t * (t - 2) + b;
        }
        Easing.easeOutQuad = easeOutQuad;
        /**
         * 入力値をeaseInOutQuadした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */
        function easeInOutQuad(t, b, c, d) {
          t /= d / 2;
          if (t < 1) return c / 2 * t * t + b;
          --t;
          return -c / 2 * (t * (t - 2) - 1) + b;
        }
        Easing.easeInOutQuad = easeInOutQuad;
        /**
         * 入力値をeaseInQubicした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */
        function easeInCubic(t, b, c, d) {
          t /= d;
          return c * t * t * t + b;
        }
        Easing.easeInCubic = easeInCubic;
        /**
         * @deprecated この関数は非推奨機能である。代わりに `easeInCubic` を用いるべきである。
         */
        Easing.easeInQubic = easeInCubic;
        /**
         * 入力値をeaseOutQubicした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */
        function easeOutCubic(t, b, c, d) {
          t /= d;
          --t;
          return c * (t * t * t + 1) + b;
        }
        Easing.easeOutCubic = easeOutCubic;
        /**
         * @deprecated この関数は非推奨機能である。代わりに `easeOutCubic` を用いるべきである。
         */
        Easing.easeOutQubic = easeOutCubic;
        /**
         * 入力値をeaseInOutQubicした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */
        function easeInOutCubic(t, b, c, d) {
          t /= d / 2;
          if (t < 1) return c / 2 * t * t * t + b;
          t -= 2;
          return c / 2 * (t * t * t + 2) + b;
        }
        Easing.easeInOutCubic = easeInOutCubic;
        /**
         * @deprecated この関数は非推奨機能である。代わりに `easeInOutCubic` を用いるべきである。
         */
        Easing.easeInOutQubic = easeInOutCubic;
        /**
         * 入力値をeaseInQuartした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */
        function easeInQuart(t, b, c, d) {
          t /= d;
          return c * t * t * t * t + b;
        }
        Easing.easeInQuart = easeInQuart;
        /**
         * 入力値をeaseOutQuartした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */
        function easeOutQuart(t, b, c, d) {
          t /= d;
          --t;
          return -c * (t * t * t * t - 1) + b;
        }
        Easing.easeOutQuart = easeOutQuart;
        /**
         * 入力値をeaseInQuintした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */
        function easeInQuint(t, b, c, d) {
          t /= d;
          return c * t * t * t * t * t + b;
        }
        Easing.easeInQuint = easeInQuint;
        /**
         * 入力値をeaseOutQuintした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */
        function easeOutQuint(t, b, c, d) {
          t /= d;
          --t;
          return c * (t * t * t * t * t + 1) + b;
        }
        Easing.easeOutQuint = easeOutQuint;
        /**
         * 入力値をeaseInOutQuintした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */
        function easeInOutQuint(t, b, c, d) {
          t /= d / 2;
          if (t < 1) return c / 2 * t * t * t * t * t + b;
          t -= 2;
          return c / 2 * (t * t * t * t * t + 2) + b;
        }
        Easing.easeInOutQuint = easeInOutQuint;
        /**
         * 入力値をeaseInSineした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */
        function easeInSine(t, b, c, d) {
          return -c * Math.cos(t / d * (Math.PI / 2)) + c + b;
        }
        Easing.easeInSine = easeInSine;
        /**
         * 入力値をeaseOutSineした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */
        function easeOutSine(t, b, c, d) {
          return c * Math.sin(t / d * (Math.PI / 2)) + b;
        }
        Easing.easeOutSine = easeOutSine;
        /**
         * 入力値をeaseInOutSineした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */
        function easeInOutSine(t, b, c, d) {
          return -c / 2 * (Math.cos(Math.PI * t / d) - 1) + b;
        }
        Easing.easeInOutSine = easeInOutSine;
        /**
         * 入力値をeaseInExpoした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */
        function easeInExpo(t, b, c, d) {
          return c * Math.pow(2, 10 * (t / d - 1)) + b;
        }
        Easing.easeInExpo = easeInExpo;
        /**
         * 入力値をeaseInOutExpoした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */
        function easeInOutExpo(t, b, c, d) {
          t /= d / 2;
          if (t < 1) return c / 2 * Math.pow(2, 10 * (t - 1)) + b;
          --t;
          return c / 2 * (-Math.pow(2, -10 * t) + 2) + b;
        }
        Easing.easeInOutExpo = easeInOutExpo;
        /**
         * 入力値をeaseInCircした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */
        function easeInCirc(t, b, c, d) {
          t /= d;
          return -c * (Math.sqrt(1 - t * t) - 1) + b;
        }
        Easing.easeInCirc = easeInCirc;
        /**
         * 入力値をeaseOutCircした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */
        function easeOutCirc(t, b, c, d) {
          t /= d;
          --t;
          return c * Math.sqrt(1 - t * t) + b;
        }
        Easing.easeOutCirc = easeOutCirc;
        /**
         * 入力値をeaseInOutCircした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */
        function easeInOutCirc(t, b, c, d) {
          t /= d / 2;
          if (t < 1) return -c / 2 * (Math.sqrt(1 - t * t) - 1) + b;
          t -= 2;
          return c / 2 * (Math.sqrt(1 - t * t) + 1) + b;
        }
        Easing.easeInOutCirc = easeInOutCirc;
        /**
         * 入力値を easeInOutBack した結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */
        function easeInOutBack(t, b, c, d) {
          var x = t / d;
          var c1 = 1.70158;
          var c2 = c1 * 1.525;
          var v = x < 0.5 ? Math.pow(2 * x, 2) * ((c2 + 1) * 2 * x - c2) / 2 : (Math.pow(2 * x - 2, 2) * ((c2 + 1) * (x * 2 - 2) + c2) + 2) / 2;
          return b + c * v;
        }
        Easing.easeInOutBack = easeInOutBack;
        /**
         * 入力値を easeOutBounce した結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */
        function easeOutBounce(t, b, c, d) {
          var x = t / d;
          var n1 = 7.5625;
          var d1 = 2.75;
          var v;
          if (x < 1 / d1) {
            v = n1 * x * x;
          } else if (x < 2 / d1) {
            v = n1 * (x -= 1.5 / d1) * x + 0.75;
          } else if (x < 2.5 / d1) {
            v = n1 * (x -= 2.25 / d1) * x + 0.9375;
          } else {
            v = n1 * (x -= 2.625 / d1) * x + 0.984375;
          }
          return b + c * v;
        }
        Easing.easeOutBounce = easeOutBounce;
      })(Easing = exports.Easing || (exports.Easing = {}));
    }, {}],
    6: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.Timeline = void 0;
      var Tween_1 = require("./Tween");
      /**
       * タイムライン機能を提供するクラス。
       */
      var Timeline = /** @class */function () {
        /**
         * Timelineを生成する。
         * @param scene タイムラインを実行する `Scene`
         */
        function Timeline(scene) {
          this._scene = scene;
          this._tweens = [];
          this._tweensCreateQue = [];
          this._fps = this._scene.game.fps;
          this.paused = false;
          scene.onUpdate.add(this._handler, this);
        }
        /**
         * Timelineに紐付いたTweenを生成する。
         * @param target タイムライン処理の対象にするオブジェクト
         * @param option Tweenの生成オプション。省略された場合、 {modified: target.modified, destroyed: target.destroyed} が与えられた時と同様の処理を行う。
         */
        Timeline.prototype.create = function (target, option) {
          var t = new Tween_1.Tween(target, option);
          this._tweensCreateQue.push(t);
          return t;
        };
        /**
         * Timelineに紐付いたTweenを削除する。
         * @param tween 削除するTween。
         */
        Timeline.prototype.remove = function (tween) {
          var index = this._tweens.indexOf(tween);
          var queIndex = this._tweensCreateQue.indexOf(tween);
          if (index < 0 && queIndex < 0) {
            return;
          }
          tween.cancel(false);
        };
        /**
         * Timelineに紐付いた全Tweenのアクションを完了させる。詳細は `Tween#complete()`の説明を参照。
         */
        Timeline.prototype.completeAll = function () {
          for (var i = 0; i < this._tweens.length; ++i) {
            var tween = this._tweens[i];
            if (!tween.isFinished()) {
              tween.complete();
            }
          }
          for (var i = 0; i < this._tweensCreateQue.length; ++i) {
            var tween = this._tweensCreateQue[i];
            if (!tween.isFinished()) {
              tween.complete();
            }
          }
        };
        /**
         * Timelineに紐付いた全Tweenのアクションを取り消す。詳細は `Tween#cancel()`の説明を参照。
         * @param revert ターゲットのプロパティをアクション開始前に戻すかどうか (指定しない場合は `false`)
         */
        Timeline.prototype.cancelAll = function (revert) {
          if (revert === void 0) {
            revert = false;
          }
          for (var i = 0; i < this._tweens.length; ++i) {
            var tween = this._tweens[i];
            if (!tween.isFinished()) {
              tween.cancel(revert);
            }
          }
          for (var i = 0; i < this._tweensCreateQue.length; ++i) {
            var tween = this._tweensCreateQue[i];
            if (!tween.isFinished()) {
              tween.cancel(revert);
            }
          }
        };
        /**
         * Timelineに紐付いた全Tweenの紐付けを解除する。
         */
        Timeline.prototype.clear = function () {
          this.cancelAll(false);
        };
        /**
         * このTimelineを破棄する。
         */
        Timeline.prototype.destroy = function () {
          this.clear();
          if (!this._scene.destroyed()) {
            this._scene.onUpdate.remove(this._handler, this);
          }
          this._scene = undefined;
        };
        /**
         * このTimelineが破棄済みであるかを返す。
         */
        Timeline.prototype.destroyed = function () {
          return this._scene === undefined;
        };
        Timeline.prototype._handler = function () {
          if (this.paused || this._tweens.length + this._tweensCreateQue.length === 0) {
            return;
          }
          this._tweens = this._tweens.concat(this._tweensCreateQue);
          this._tweensCreateQue = [];
          var tmp = [];
          for (var i = 0; i < this._tweens.length; ++i) {
            var tween = this._tweens[i];
            if (!tween.shouldRemove()) {
              tween._fire(1000 / this._fps);
              tmp.push(tween);
            }
          }
          this._tweens = tmp;
        };
        return Timeline;
      }();
      exports.Timeline = Timeline;
    }, {
      "./Tween": 7
    }],
    7: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.Tween = void 0;
      var ActionType_1 = require("./ActionType");
      var Easing_1 = require("./Easing");
      /**
       * オブジェクトの状態を変化させるアクションを定義するクラス。
       * 本クラスのインスタンス生成には`Timeline#create()`を利用する。
       */
      var Tween = /** @class */function () {
        /**
         * Tweenを生成する。
         * @param target 対象となるオブジェクト
         * @param option オプション
         */
        function Tween(target, option) {
          this._target = target;
          this._stepIndex = 0;
          this._loop = !!option && !!option.loop;
          this._stale = false;
          this._modifiedHandler = undefined;
          if (option && option.modified) {
            this._modifiedHandler = option.modified;
          } else if (target && target.modified) {
            this._modifiedHandler = target.modified;
          }
          this._destroyedHandler = undefined;
          if (option && option.destroyed) {
            this._destroyedHandler = option.destroyed;
          } else if (target && target.destroyed) {
            this._destroyedHandler = target.destroyed;
          }
          this._steps = [];
          this._lastStep = undefined;
          this._pararel = false;
          this._initialProp = {};
          this.paused = false;
        }
        /**
         * オブジェクトの状態を変化させるアクションを追加する。
         * @param props 変化内容
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */
        Tween.prototype.to = function (props, duration, easing) {
          if (easing === void 0) {
            easing = Easing_1.Easing.linear;
          }
          var action = {
            input: props,
            duration: duration,
            easing: easing,
            type: ActionType_1.ActionType.TweenTo,
            initialized: false
          };
          this._push(action);
          return this;
        };
        /**
         * オブジェクトの状態を変化させるアクションを追加する。
         * 変化内容はアクション開始時を基準とした相対値で指定する。
         * @param props 変化内容
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         * @param multiply `true`を指定すると`props`の値をアクション開始時の値に掛け合わせた値が終了値となる（指定しない場合は`false`）
         */
        Tween.prototype.by = function (props, duration, easing, multiply) {
          if (easing === void 0) {
            easing = Easing_1.Easing.linear;
          }
          if (multiply === void 0) {
            multiply = false;
          }
          var type = multiply ? ActionType_1.ActionType.TweenByMult : ActionType_1.ActionType.TweenBy;
          var action = {
            input: props,
            duration: duration,
            easing: easing,
            type: type,
            initialized: false
          };
          this._push(action);
          return this;
        };
        /**
         * 次に追加されるアクションを、このメソッド呼び出しの直前に追加されたアクションと並列に実行させる。
         * `Tween#con()`で並列実行を指定されたアクションが全て終了後、次の並列実行を指定されていないアクションを実行する。
         */
        Tween.prototype.con = function () {
          this._pararel = true;
          return this;
        };
        /**
         * オブジェクトの変化を停止するアクションを追加する。
         * @param duration 停止する時間（ミリ秒）
         */
        Tween.prototype.wait = function (duration) {
          var action = {
            duration: duration,
            type: ActionType_1.ActionType.Wait,
            initialized: false
          };
          this._push(action);
          return this;
        };
        /**
         * 関数を即座に実行するアクションを追加する。
         * @param func 実行する関数
         */
        Tween.prototype.call = function (func) {
          var action = {
            func: func,
            type: ActionType_1.ActionType.Call,
            duration: 0,
            initialized: false
          };
          this._push(action);
          return this;
        };
        /**
         * 一時停止するアクションを追加する。
         * 内部的には`Tween#call()`で`Tween#paused`に`true`をセットしている。
         */
        Tween.prototype.pause = function () {
          var _this = this;
          return this.call(function () {
            _this.paused = true;
          });
        };
        /**
         * 待機時間をキーとして実行したい関数を複数指定する。
         * @param actions 待機時間をキーとして実行したい関数を値としたオブジェクト
         */
        Tween.prototype.cue = function (funcs) {
          var keys = Object.keys(funcs);
          keys.sort(function (a, b) {
            return Number(a) > Number(b) ? 1 : -1;
          });
          var q = [];
          for (var i = 0; i < keys.length; ++i) {
            q.push({
              time: Number(keys[i]),
              func: funcs[keys[i]]
            });
          }
          var action = {
            type: ActionType_1.ActionType.Cue,
            duration: Number(keys[keys.length - 1]),
            cue: q,
            initialized: false
          };
          this._push(action);
          return this;
        };
        /**
         * 指定した時間を経過するまで毎フレーム指定した関数を呼び出すアクションを追加する。
         * @param func 毎フレーム呼び出される関数。第一引数は経過時間、第二引数はEasingした結果の変化量（0-1）となる。
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */
        Tween.prototype.every = function (func, duration, easing) {
          if (easing === void 0) {
            easing = Easing_1.Easing.linear;
          }
          var action = {
            func: func,
            type: ActionType_1.ActionType.Every,
            easing: easing,
            duration: duration,
            initialized: false
          };
          this._push(action);
          return this;
        };
        /**
         * ターゲットをフェードインさせるアクションを追加する。
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */
        Tween.prototype.fadeIn = function (duration, easing) {
          if (easing === void 0) {
            easing = Easing_1.Easing.linear;
          }
          return this.to({
            opacity: 1
          }, duration, easing);
        };
        /**
         * ターゲットをフェードアウトさせるアクションを追加する。
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */
        Tween.prototype.fadeOut = function (duration, easing) {
          if (easing === void 0) {
            easing = Easing_1.Easing.linear;
          }
          return this.to({
            opacity: 0
          }, duration, easing);
        };
        /**
         * ターゲットを指定した座標に移動するアクションを追加する。
         * @param x x座標
         * @param y y座標
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */
        Tween.prototype.moveTo = function (x, y, duration, easing) {
          if (easing === void 0) {
            easing = Easing_1.Easing.linear;
          }
          return this.to({
            x: x,
            y: y
          }, duration, easing);
        };
        /**
         * ターゲットを指定した相対座標に移動するアクションを追加する。相対座標の基準値はアクション開始時の座標となる。
         * @param x x座標
         * @param y y座標
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */
        Tween.prototype.moveBy = function (x, y, duration, easing) {
          if (easing === void 0) {
            easing = Easing_1.Easing.linear;
          }
          return this.by({
            x: x,
            y: y
          }, duration, easing);
        };
        /**
         * ターゲットのX座標を指定した座標に移動するアクションを追加する。
         * @param x x座標
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */
        Tween.prototype.moveX = function (x, duration, easing) {
          if (easing === void 0) {
            easing = Easing_1.Easing.linear;
          }
          return this.to({
            x: x
          }, duration, easing);
        };
        /**
         * ターゲットのY座標を指定した座標に移動するアクションを追加する。
         * @param y y座標
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */
        Tween.prototype.moveY = function (y, duration, easing) {
          if (easing === void 0) {
            easing = Easing_1.Easing.linear;
          }
          return this.to({
            y: y
          }, duration, easing);
        };
        /**
         * ターゲットを指定した角度に回転するアクションを追加する。
         * @param angle 角度
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */
        Tween.prototype.rotateTo = function (angle, duration, easing) {
          if (easing === void 0) {
            easing = Easing_1.Easing.linear;
          }
          return this.to({
            angle: angle
          }, duration, easing);
        };
        /**
         * ターゲットをアクション開始時の角度を基準とした相対角度に回転するアクションを追加する。
         * @param angle 角度
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */
        Tween.prototype.rotateBy = function (angle, duration, easing) {
          if (easing === void 0) {
            easing = Easing_1.Easing.linear;
          }
          return this.by({
            angle: angle
          }, duration, easing);
        };
        /**
         * ターゲットを指定した倍率に拡縮するアクションを追加する。
         * @param scaleX X方向の倍率
         * @param scaleY Y方向の倍率
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */
        Tween.prototype.scaleTo = function (scaleX, scaleY, duration, easing) {
          if (easing === void 0) {
            easing = Easing_1.Easing.linear;
          }
          return this.to({
            scaleX: scaleX,
            scaleY: scaleY
          }, duration, easing);
        };
        /**
         * ターゲットのアクション開始時の倍率に指定した倍率を掛け合わせた倍率に拡縮するアクションを追加する。
         * @param scaleX X方向の倍率
         * @param scaleY Y方向の倍率
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */
        Tween.prototype.scaleBy = function (scaleX, scaleY, duration, easing) {
          if (easing === void 0) {
            easing = Easing_1.Easing.linear;
          }
          return this.by({
            scaleX: scaleX,
            scaleY: scaleY
          }, duration, easing, true);
        };
        /**
         * このTweenに追加されたすべてのアクションを即座に完了する。
         * `Tween#loop`が`true`の場合、ループの終端までのアクションがすべて実行される。
         */
        Tween.prototype.complete = function () {
          for (var i = this._stepIndex; i < this._steps.length; ++i) {
            for (var j = 0; j < this._steps[i].length; ++j) {
              var action = this._steps[i][j];
              if (!action.initialized) {
                this._initAction(action);
              }
              var keys = Object.keys(action.goal);
              for (var k = 0; k < keys.length; ++k) {
                var key = keys[k];
                this._target[key] = action.goal[key];
              }
              if (action.type === ActionType_1.ActionType.Call && typeof action.func === "function") {
                action.func.call(this._target);
              } else if (action.type === ActionType_1.ActionType.Cue && action.cue) {
                for (var k = 0; k < action.cue.length; ++k) {
                  action.cue[k].func.call(this._target);
                }
              } else if (action.type === ActionType_1.ActionType.Every && typeof action.func === "function") {
                action.func.call(this._target, action.duration, 1);
              }
            }
          }
          this._stepIndex = this._steps.length;
          this._loop = false;
          this._lastStep = undefined;
          this._pararel = false;
          this.paused = false;
          if (this._modifiedHandler) {
            this._modifiedHandler.call(this._target);
          }
        };
        /**
         * このTweenに追加されたすべてのアクションを取り消す。
         * `revert`を`true` にした場合、ターゲットのプロパティをアクション開始前に戻す。
         * ただし`Tween#call()`や`Tween#every()`により変更されたプロパティは戻らない点に注意。
         * @param revert ターゲットのプロパティをアクション開始前に戻すかどうか (指定しない場合は `false`)
         */
        Tween.prototype.cancel = function (revert) {
          if (revert === void 0) {
            revert = false;
          }
          if (revert) {
            var keys = Object.keys(this._initialProp);
            for (var i = 0; i < keys.length; ++i) {
              var key = keys[i];
              this._target[key] = this._initialProp[key];
            }
          }
          this._stepIndex = this._steps.length;
          this._loop = false;
          this._lastStep = undefined;
          this._pararel = false;
          this.paused = false;
          this._stale = true;
          if (this._modifiedHandler) {
            this._modifiedHandler.call(this._target);
          }
        };
        /**
         * アニメーションが終了しているかどうかを返す。
         * `_target`が破棄された場合又は、全アクションの実行が終了した場合に`true`を返す。
         */
        Tween.prototype.isFinished = function () {
          var ret = false;
          if (this._destroyedHandler) {
            ret = this._destroyedHandler.call(this._target);
          }
          if (!ret) {
            ret = this._stepIndex !== 0 && this._stepIndex >= this._steps.length && !this._loop;
          }
          return ret;
        };
        /**
         * アニメーションが削除可能かどうかを返す。
         * 通常、ゲーム開発者がこのメソッドを呼び出す必要はない。
         */
        Tween.prototype.shouldRemove = function () {
          return this._stale || this.isFinished();
        };
        /**
         * アニメーションを実行する。
         * @param delta 前フレームからの経過時間
         */
        Tween.prototype._fire = function (delta) {
          if (this._steps.length === 0 || this.isFinished() || this.paused) {
            return;
          }
          if (this._stepIndex >= this._steps.length) {
            if (this._loop) {
              this._stepIndex = 0;
            } else {
              return;
            }
          }
          var actions = this._steps[this._stepIndex];
          var remained = false;
          for (var i = 0; i < actions.length; ++i) {
            var action = actions[i];
            if (!action.initialized) {
              this._initAction(action);
            }
            if (action.finished) {
              continue;
            }
            action.elapsed += delta;
            switch (action.type) {
              case ActionType_1.ActionType.Call:
                action.func.call(this._target);
                break;
              case ActionType_1.ActionType.Every:
                var elapsed = Math.min(action.elapsed, action.duration);
                var progress = action.easing(elapsed, 0, 1, action.duration);
                if (progress > 1) {
                  progress = 1;
                }
                action.func.call(this._target, elapsed, progress);
                break;
              case ActionType_1.ActionType.TweenTo:
              case ActionType_1.ActionType.TweenBy:
              case ActionType_1.ActionType.TweenByMult:
                var keys = Object.keys(action.goal);
                for (var j = 0; j < keys.length; ++j) {
                  var key = keys[j];
                  // アクションにより undefined が指定されるケースと初期値を区別するため Object.prototype.hasOwnProperty() を利用
                  // (number以外が指定されるケースは存在しないが念の為)
                  if (!this._initialProp.hasOwnProperty(key)) {
                    this._initialProp[key] = this._target[key];
                  }
                  if (action.elapsed >= action.duration) {
                    this._target[key] = action.goal[key];
                  } else {
                    this._target[key] = action.easing(action.elapsed, action.start[key], action.goal[key] - action.start[key], action.duration);
                  }
                }
                break;
              case ActionType_1.ActionType.Cue:
                var cueAction = action.cue[action.cueIndex];
                if (cueAction !== undefined && action.elapsed >= cueAction.time) {
                  cueAction.func.call(this._target);
                  ++action.cueIndex;
                }
                break;
            }
            if (this._modifiedHandler) {
              this._modifiedHandler.call(this._target);
            }
            if (action.elapsed >= action.duration) {
              action.finished = true;
            } else {
              remained = true;
            }
          }
          if (!remained) {
            for (var k = 0; k < actions.length; ++k) {
              actions[k].initialized = false;
            }
            ++this._stepIndex;
          }
        };
        /**
         * Tweenの実行状態をシリアライズして返す。
         */
        Tween.prototype.serializeState = function () {
          var tData = {
            _stepIndex: this._stepIndex,
            _initialProp: this._initialProp,
            _steps: []
          };
          for (var i = 0; i < this._steps.length; ++i) {
            tData._steps[i] = [];
            for (var j = 0; j < this._steps[i].length; ++j) {
              tData._steps[i][j] = {
                input: this._steps[i][j].input,
                start: this._steps[i][j].start,
                goal: this._steps[i][j].goal,
                duration: this._steps[i][j].duration,
                elapsed: this._steps[i][j].elapsed,
                type: this._steps[i][j].type,
                cueIndex: this._steps[i][j].cueIndex,
                initialized: this._steps[i][j].initialized,
                finished: this._steps[i][j].finished
              };
            }
          }
          return tData;
        };
        /**
         * Tweenの実行状態を復元する。
         * @param serializedstate 復元に使う情報。
         */
        Tween.prototype.deserializeState = function (serializedState) {
          this._stepIndex = serializedState._stepIndex;
          this._initialProp = serializedState._initialProp;
          for (var i = 0; i < serializedState._steps.length; ++i) {
            for (var j = 0; j < serializedState._steps[i].length; ++j) {
              if (!serializedState._steps[i][j] || !this._steps[i][j]) continue;
              this._steps[i][j].input = serializedState._steps[i][j].input;
              this._steps[i][j].start = serializedState._steps[i][j].start;
              this._steps[i][j].goal = serializedState._steps[i][j].goal;
              this._steps[i][j].duration = serializedState._steps[i][j].duration;
              this._steps[i][j].elapsed = serializedState._steps[i][j].elapsed;
              this._steps[i][j].type = serializedState._steps[i][j].type;
              this._steps[i][j].cueIndex = serializedState._steps[i][j].cueIndex;
              this._steps[i][j].initialized = serializedState._steps[i][j].initialized;
              this._steps[i][j].finished = serializedState._steps[i][j].finished;
            }
          }
        };
        /**
         * `this._pararel`が`false`の場合は新規にステップを作成し、アクションを追加する。
         * `this._pararel`が`true`の場合は最後に作成したステップにアクションを追加する。
         */
        Tween.prototype._push = function (action) {
          if (this._pararel) {
            this._lastStep.push(action);
          } else {
            var index = this._steps.push([action]) - 1;
            this._lastStep = this._steps[index];
          }
          this._pararel = false;
        };
        Tween.prototype._initAction = function (action) {
          action.elapsed = 0;
          action.start = {};
          action.goal = {};
          action.cueIndex = 0;
          action.finished = false;
          action.initialized = true;
          if (action.type !== ActionType_1.ActionType.TweenTo && action.type !== ActionType_1.ActionType.TweenBy && action.type !== ActionType_1.ActionType.TweenByMult) {
            return;
          }
          var keys = Object.keys(action.input);
          for (var i = 0; i < keys.length; ++i) {
            var key = keys[i];
            if (this._target[key] !== undefined) {
              action.start[key] = this._target[key];
              if (action.type === ActionType_1.ActionType.TweenTo) {
                action.goal[key] = action.input[key];
              } else if (action.type === ActionType_1.ActionType.TweenBy) {
                action.goal[key] = action.start[key] + action.input[key];
              } else if (action.type === ActionType_1.ActionType.TweenByMult) {
                action.goal[key] = action.start[key] * action.input[key];
              }
            }
          }
        };
        return Tween;
      }();
      exports.Tween = Tween;
    }, {
      "./ActionType": 4,
      "./Easing": 5
    }],
    8: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.Easing = exports.Tween = exports.Timeline = void 0;
      var Timeline_1 = require("./Timeline");
      Object.defineProperty(exports, "Timeline", {
        enumerable: true,
        get: function get() {
          return Timeline_1.Timeline;
        }
      });
      var Tween_1 = require("./Tween");
      Object.defineProperty(exports, "Tween", {
        enumerable: true,
        get: function get() {
          return Tween_1.Tween;
        }
      });
      var Easing_1 = require("./Easing");
      Object.defineProperty(exports, "Easing", {
        enumerable: true,
        get: function get() {
          return Easing_1.Easing;
        }
      });
    }, {
      "./Easing": 5,
      "./Timeline": 6,
      "./Tween": 7
    }],
    9: [function (require, module, exports) {
      "use strict";

      var __assign = this && this.__assign || function () {
        __assign = Object.assign || function (t) {
          for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
          }
          return t;
        };
        return __assign.apply(this, arguments);
      };
      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.FallbackDialog = void 0;
      var akashic_hover_plugin_1 = require("@akashic-extension/akashic-hover-plugin");
      var HoverPluginRaw = require("@akashic-extension/akashic-hover-plugin/lib/HoverPlugin");
      // Ugh! HoverPlugin が Akashic Engine 向けに中途半端に CommonJS で (module.exports = HoverPlugin と)
      // 定義されている関係で、 import すると TS の型と実体が合わない。無理やり解消する。
      // (import * as ... すると、 JS 的には HoverPlugin の実体が手に入るが、TS 上では namespace と誤認される)
      // さらにおそらく akashic-hover-plugin 側のバグで、型があっていないのでそれも無理やり合わせる。
      // (コンストラクタ第二引数が間違っている。実装上は any キャストして正しく使っている)
      var HoverPlugin = HoverPluginRaw;
      function drawCircle(rendr, centerX, centerY, radius, cssColor) {
        for (var y = centerY - radius | 0; y <= Math.ceil(centerY + radius); ++y) {
          var w = radius * Math.cos(Math.asin((centerY - y) / radius));
          rendr.fillRect(centerX - w, y, 2 * w, 1, cssColor);
        }
      }
      function makeSurface(w, h, drawer) {
        var s = g.game.resourceFactory.createSurface(Math.ceil(w), Math.ceil(h));
        var r = s.renderer();
        r.begin();
        drawer(r);
        r.end();
        return s;
      }
      function animate(e, motions) {
        var onEnd = new g.Trigger();
        var frameTime = 1000 / g.game.fps;
        var step = 0;
        var time = 0;
        var mot = motions[0];
        var ended = false;
        function update(delta) {
          time += delta;
          if (time > mot.duration) {
            ended = ++step >= motions.length;
            if (ended) {
              time = mot.duration;
              e.scene.onUpdate.addOnce(onEnd.fire, onEnd);
            } else {
              time -= mot.duration;
              mot = motions[step];
            }
          }
          var r = Math.min(1, time / mot.duration);
          var scale = mot.scale,
            opacity = mot.opacity;
          if (scale) e.scaleX = e.scaleY = scale[0] + (scale[1] - scale[0]) * r;
          if (opacity) e.opacity = opacity[0] + (opacity[1] - opacity[0]) * r;
          e.modified();
          return ended;
        }
        update(0);
        e.onUpdate.add(function () {
          return update(frameTime);
        });
        return onEnd;
      }
      var FallbackDialog = /** @class */function () {
        function FallbackDialog(name) {
          var _this = this;
          this.onEnd = new g.Trigger();
          this.isHoverPluginStarted = false;
          this.timer = null;
          if (!FallbackDialog.isSupported()) return;
          var game = g.game;
          var gameWidth = game.width,
            gameHeight = game.height;
          var baseWidth = 1280;
          var ratio = gameWidth / baseWidth;
          var titleFontSize = Math.round(32 * ratio);
          var fontSize = Math.round(28 * ratio);
          var lineMarginRate = 0.3;
          var lineHeightRate = 1 + lineMarginRate;
          var titleTopMargin = 80 * ratio;
          var titleBotMargin = 32 * ratio;
          var buttonTopMargin = 42 * ratio;
          var buttonWidth = 360 * ratio;
          var buttonHeight = 82 * ratio;
          var buttonBotMargin = 72 * ratio;
          var colorBlue = "#4a8de1";
          var colorWhite = "#fff";
          var dialogWidth = 960 * ratio | 0;
          var dialogHeight = titleTopMargin + titleFontSize * lineHeightRate * 2 + titleBotMargin + (fontSize + fontSize * lineHeightRate) +
          // 一行目のマージンは titleBotMargin に繰り込まれている
          buttonTopMargin + buttonHeight + buttonBotMargin | 0;
          var font = new g.DynamicFont({
            game: g.game,
            fontFamily: g.FontFamily.SansSerif,
            size: titleFontSize,
            fontWeight: g.FontWeight.Bold,
            fontColor: "#252525"
          });
          var surfSize = Math.ceil(32 * ratio) & ~1; // 切り上げて偶数に丸める
          var surfHalf = surfSize / 2;
          var dialogBgSurf = makeSurface(surfSize, surfSize, function (r) {
            return drawCircle(r, surfHalf, surfHalf, surfHalf, colorWhite);
          });
          var btnActiveBgSurf = makeSurface(surfSize, surfSize, function (r) {
            return drawCircle(r, surfHalf, surfHalf, surfHalf, colorBlue);
          });
          var btnBgSurf = makeSurface(surfSize, surfSize, function (r) {
            drawCircle(r, surfHalf, surfHalf, surfHalf, colorBlue);
            drawCircle(r, surfHalf, surfHalf, 12 * ratio, colorWhite);
          });
          function makeLabel(param) {
            return new g.Label(__assign({
              scene: scene,
              font: font,
              local: true,
              textAlign: g.TextAlign.Center,
              widthAutoAdjust: false
            }, param));
          }
          var scene = this.scene = game.scene();
          var bg = this.bgRect = new g.FilledRect({
            scene: scene,
            local: true,
            width: gameWidth,
            height: gameHeight,
            cssColor: "rgba(0, 0, 0, 0.5)",
            touchable: true // 後ろの touch を奪って modal にする
          });
          var dialogPane = this.dialogPane = new g.Pane({
            scene: scene,
            local: true,
            width: dialogWidth,
            height: dialogHeight,
            anchorX: 0.5,
            anchorY: 0.5,
            x: game.width / 2 | 0,
            y: game.height / 2 | 0,
            backgroundImage: dialogBgSurf,
            backgroundEffector: new g.NinePatchSurfaceEffector(game, dialogBgSurf.width / 2 - 1),
            parent: bg
          });
          var dialogTextX = 80 * ratio | 0;
          var dialogTextWidth = 800 * ratio | 0;
          var y = 0;
          y += titleTopMargin + titleFontSize * lineMarginRate | 0;
          dialogPane.append(makeLabel({
            x: dialogTextX,
            y: y,
            text: "このコンテンツは名前を利用します。",
            fontSize: titleFontSize,
            width: dialogTextWidth
          }));
          y += titleFontSize * lineHeightRate | 0;
          dialogPane.append(makeLabel({
            x: dialogTextX,
            y: y,
            text: "\u3042\u306A\u305F\u306F\u300C" + name + "\u300D\u3067\u3059\u3002",
            fontSize: titleFontSize,
            width: dialogTextWidth
          }));
          y += titleFontSize + titleBotMargin | 0;
          dialogPane.append(makeLabel({
            x: dialogTextX,
            y: y,
            text: "ユーザ名で参加するには、",
            fontSize: fontSize,
            width: dialogTextWidth
          }));
          y += fontSize * lineHeightRate | 0;
          dialogPane.append(makeLabel({
            x: dialogTextX,
            y: y,
            text: "最新のニコニコ生放送アプリに更新してください。",
            fontSize: fontSize,
            width: dialogTextWidth
          }));
          y += fontSize + buttonTopMargin | 0;
          var buttonPane = new g.Pane({
            scene: scene,
            local: true,
            width: buttonWidth,
            height: buttonHeight,
            x: dialogWidth / 2,
            y: y + buttonHeight / 2,
            anchorX: 0.5,
            anchorY: 0.5,
            backgroundImage: btnBgSurf,
            backgroundEffector: new g.NinePatchSurfaceEffector(game, btnBgSurf.width / 2 - 1),
            parent: scene,
            touchable: true
          });
          dialogPane.append(buttonPane);
          var buttonLabel = this.buttonLabel = makeLabel({
            x: 0,
            y: (buttonHeight - titleFontSize) / 2 - 5 * ratio,
            text: "OK (15)",
            fontSize: titleFontSize,
            width: buttonWidth,
            textColor: colorBlue
          });
          buttonPane.append(buttonLabel);
          var activateButton = function activateButton() {
            buttonPane.backgroundImage = btnActiveBgSurf;
            buttonPane.invalidate();
            buttonLabel.textColor = colorWhite;
            buttonLabel.invalidate();
          };
          var deactivateButton = function deactivateButton() {
            buttonPane.backgroundImage = btnBgSurf;
            buttonPane.invalidate();
            buttonLabel.textColor = colorBlue;
            buttonLabel.invalidate();
          };
          var h = akashic_hover_plugin_1.Converter.asHoverable(buttonPane);
          var animating = false;
          h.hovered.add(function () {
            activateButton();
            if (animating) return;
            animating = true;
            animate(buttonPane, [{
              duration: 16,
              scale: [1.0, 0.9]
            }, {
              duration: 16,
              scale: [0.9, 1.1]
            }, {
              duration: 33,
              scale: [1.1, 1.0]
            }]).add(function () {
              return animating = false;
            });
          });
          h.unhovered.add(deactivateButton);
          buttonPane.onPointDown.add(activateButton);
          buttonPane.onPointUp.add(function () {
            _this.end();
          });
          if (!game.operationPluginManager.plugins[FallbackDialog.HOVER_PLUGIN_OPCODE]) game.operationPluginManager.register(HoverPlugin, FallbackDialog.HOVER_PLUGIN_OPCODE);
        }
        FallbackDialog.isSupported = function () {
          // 縦横比 0.4 について: このダイアログは 16:9 の解像度で画面高さの約 65% (468px) を占有する。
          // すなわち画面高さが画面幅の約 37% 以下の場合画面に収まらない。余裕を見て 40% を下限とする。
          // (詳細な高さは下の dialogHeight の定義を参照せよ)
          return typeof window !== "undefined" && g.game.height / g.game.width >= 0.4 && HoverPlugin.isSupported();
        };
        FallbackDialog.prototype.start = function (remainingSeconds) {
          var _this = this;
          var game = g.game;
          var scene = this.scene;
          if (game.scene() !== scene) {
            // ないはずの異常系だが一応確認
            return;
          }
          // エッジケース考慮: hoverプラグインは必ず停止したいので、シーンが変わった時点で止めてしまう。
          // (mouseover契機で無駄にエンティティ検索したくない)
          game.onSceneChange.add(this._disablePluginOnSceneChange, this);
          game.operationPluginManager.start(FallbackDialog.HOVER_PLUGIN_OPCODE);
          this.isHoverPluginStarted = true;
          animate(this.dialogPane, [{
            duration: 100,
            scale: [0.5, 1.1],
            opacity: [0.5, 1.0]
          }, {
            duration: 100,
            scale: [1.1, 1.0],
            opacity: [1.0, 1.0]
          }]);
          scene.append(this.bgRect);
          scene.onUpdate.add(this._assureFrontmost, this);
          this.timer = scene.setInterval(function () {
            remainingSeconds -= 1;
            _this.buttonLabel.text = "OK (" + remainingSeconds + ")";
            _this.buttonLabel.invalidate();
            if (remainingSeconds <= 0) {
              _this.end();
            }
          }, 1000);
        };
        FallbackDialog.prototype.end = function () {
          var _this = this;
          if (this.timer) {
            this.scene.clearInterval(this.timer);
            this.timer = null;
          }
          // 厳密には下のアニメーション終了後に解除する方がよいが、
          // 途中でシーンが破棄されるエッジケースを想定してこの時点で止める。
          this.scene.onUpdate.remove(this._assureFrontmost, this);
          if (this.isHoverPluginStarted) {
            g.game.operationPluginManager.stop(FallbackDialog.HOVER_PLUGIN_OPCODE);
            this.isHoverPluginStarted = false;
          }
          animate(this.dialogPane, [{
            duration: 100,
            opacity: [1, 0],
            scale: [1, 0.8]
          }]);
          var t = animate(this.bgRect, [{
            duration: 100,
            opacity: [1, 0]
          }]);
          t.add(function () {
            var onEnd = _this.onEnd;
            _this.onEnd = null;
            _this.bgRect.destroy();
            _this.bgRect = null;
            _this.dialogPane = null;
            _this.scene = null;
            onEnd.fire();
          });
        };
        FallbackDialog.prototype._disablePluginOnSceneChange = function (scene) {
          if (scene !== this.scene) {
            g.game.operationPluginManager.stop(FallbackDialog.HOVER_PLUGIN_OPCODE);
            return true;
          }
        };
        // フレーム終了時に確実に画面最前面に持ってくる
        FallbackDialog.prototype._assureFrontmost = function () {
          g.game._pushPostTickTask(this._doAssureFrontmost, this);
        };
        FallbackDialog.prototype._doAssureFrontmost = function () {
          var scene = this.scene;
          if (scene && g.game.scene() !== scene) return;
          if (scene.children[scene.children.length - 1] === this.bgRect) return;
          this.bgRect.remove();
          scene.append(this.bgRect);
        };
        FallbackDialog.HOVER_PLUGIN_OPCODE = -1000; // TODO: 定数予約
        return FallbackDialog;
      }();
      exports.FallbackDialog = FallbackDialog;
    }, {
      "@akashic-extension/akashic-hover-plugin": 3,
      "@akashic-extension/akashic-hover-plugin/lib/HoverPlugin": 2
    }],
    10: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.resolvePlayerInfo = void 0;
      var FallbackDialog_1 = require("./FallbackDialog");
      function createRandomName() {
        return "ゲスト" + (Math.random() * 1000 | 0);
      }
      var resolvers = [
      // coeLimited
      {
        isSupported: function isSupported() {
          var coeLimited = g.game.external.coeLimited;
          return !!(coeLimited && coeLimited.startLocalSession && coeLimited.exitLocalSession);
        },
        resolve: function resolve(limitSeconds, callback) {
          var sessionId = g.game.playId + "__player-info-resolver";
          var scene = g.game.scene();
          var timeoutId = scene.setTimeout(function () {
            timeoutId = null;
            // NOTE: スキップ時は既に終了済みのローカルセッション自体が起動せず messageHandler() も呼ばれなるため、
            // ここで callback() を呼ばないとコンテンツ側がコールバックをいつまでも待ってしまう状態になってしまう
            callback(null, {
              name: null,
              userData: {
                accepted: false,
                premium: false
              }
            });
            // NOTE: リアルタイム視聴の場合、大半のケースではこちらのパスには到達しないはず
            // (仮に到達しても同一セッションIDの COE#exitSession() が呼ばれるのみ)
            // 追っかけ再生またはタイムシフトによる視聴においては、
            // player-info-resolver の自発終了よりも先に以下の exitLocalSession() を呼ぶことで
            // 「スキップ中のセッション起動を抑止する」というプラットフォーム側の機能を有効にしている
            g.game.external.coeLimited.exitLocalSession(sessionId, {
              needsResult: true
            });
          }, (limitSeconds + 2) * 1000); // NOTE: 読み込みなどを考慮して 2 秒のバッファを取る
          g.game.external.coeLimited.startLocalSession({
            sessionId: sessionId,
            applicationName: "player-info-resolver",
            localEvents: [[32, 0, ":akashic", {
              type: "start",
              parameters: {
                limitSeconds: limitSeconds
              }
            }]],
            messageHandler: function messageHandler(message) {
              if (timeoutId == null) {
                // 先にタイムアウト処理が実行されていたら何もしない
                return;
              }
              scene.clearTimeout(timeoutId);
              // TODO 引数からエラーを取得できるようになったら、異常系の処理も行う
              callback(null, message.result);
            }
          });
        }
      },
      // FallbackDialog
      {
        isSupported: FallbackDialog_1.FallbackDialog.isSupported,
        resolve: function resolve(limitSeconds, callback) {
          var name = createRandomName();
          var dialog = new FallbackDialog_1.FallbackDialog(name);
          dialog.start(limitSeconds);
          dialog.onEnd.addOnce(function () {
            callback(null, {
              name: name,
              userData: {
                accepted: false,
                premium: false
              }
            });
          });
        }
      },
      // sentinel
      {
        isSupported: function isSupported() {
          return true;
        },
        resolve: function resolve(_limitSeconds, callback) {
          callback(null, {
            name: "",
            userData: {
              accepted: false,
              premium: false,
              unnamed: true
            }
          });
        }
      }];
      var DEFAULT_LIMIT_SECONDS = 15;
      // resolvePlayerInfo() の多重呼び出し防止フラグ
      var isResolving = false;
      function find(xs, pred) {
        for (var i = 0; i < xs.length; ++i) {
          if (pred(xs[i])) return xs[i];
        }
        return undefined;
      }
      /**
       * ユーザー情報の取得と通知を行う
       * @param opts ユーザ情報取得時のオプション
       * @param callback 指定された場合、playerInfo が取得成功・失敗した時点の次の local/non-local tick で呼び出される
       */
      exports.resolvePlayerInfo = function (opts, callback) {
        if (isResolving) {
          callback === null || callback === void 0 ? void 0 : callback(new Error("Last processing has not yet been completed."), null);
          return;
        }
        var cb = function cb(err, info) {
          isResolving = false;
          callback === null || callback === void 0 ? void 0 : callback(err, info);
          if (!err) {
            var _a = info,
              name_1 = _a.name,
              userData = _a.userData;
            if (opts && opts.raises && (!userData || !userData.unnamed)) {
              g.game.raiseEvent(new g.PlayerInfoEvent({
                id: g.game.selfId,
                name: name_1,
                userData: userData
              }));
            }
          }
        };
        var limitSeconds = opts && opts.limitSeconds ? opts.limitSeconds : DEFAULT_LIMIT_SECONDS;
        var resolver = find(resolvers, function (r) {
          return r.isSupported();
        }); // isSupported() が恒真の実装があるので non-null
        try {
          isResolving = true;
          resolver.resolve(limitSeconds, cb);
        } catch (e) {
          cb(e);
        }
      };
    }, {
      "./FallbackDialog": 9
    }],
    11: [function (require, module, exports) {
      var y_limit = 80;
      var overlap_threshold = 25;
      var broadcasterPlayer = "";
      var broadcasterPlayerId = "";
      var resolvePlayerInfo = require("@akashic-extension/resolve-player-info");
      var tween_animation = require("@akashic-extension/akashic-timeline");
      var PlayerDatas = [{}];
      var PlayerIds = [];
      var sotugyolabels = [];
      var taigakulabels = [];
      var font = new g.DynamicFont({
        game: g.game,
        fontFamily: "sans-serif",
        size: 45
      });
      function main(param) {
        var assetIds = ["title", "rule", "haikei", "bgm1", "Main_botti", "NPC_botti", "Nushi_botti", "Main_OK", "NPC_OK", "Nushi_OK", "bgm2", "sotugyo", "taiho"];
        var scene = new g.Scene({
          game: g.game,
          assetIds: assetIds
        });
        var timeline = new tween_animation.Timeline(scene);
        var startThen = false;
        var gameNowThen = false;
        var gameendThen = false;
        var sotugyoThen = false;
        var gamesecond = 15;
        var gametime = 0;
        var titleObj, settingObj, settingstrs, sankaObj, startObj, playercntObj;
        var bgm1, bgm2;
        var backlayer = new g.E({
          scene: scene,
          parent: scene
        }); //背景
        var buttonlayer = new g.E({
          scene: scene,
          parent: scene
        }); //ボタン

        scene.onLoad.add(function () {
          //BGMは参加の有無に関係なく全員に流す
          bgm1 = scene.asset.getAudio("/audio/suspense_piano").play();
          bgm1.changeVolume(0.1);

          /////////////////
          ////放送主判定////
          /////////////////
          g.game.onJoin.add(function (ev) {
            broadcasterPlayerId = ev.player.id; // 放送者のプレイヤーID
            // 自分が放送者なら、「締め切る」ボタンを表示。
            if (g.game.selfId === broadcasterPlayerId) {
              broadcasterPlayer = ev.player.name;
              settingObj.forEach(function (Obj) {
                Obj.touchable = true;
              });
              //参加処理
              resolvePlayerInfo.resolvePlayerInfo({
                raises: true
              });
              sankaObj.forEach(function (Obj) {
                Obj.touchable = false;
                Obj.hide();
              });
              sankaObj.forEach(function (Obj) {
                Obj.modified();
              });
            } else {
              startObj.forEach(function (Obj) {
                Obj.hide();
                Obj.touchable = false;
              });
              settingObj.forEach(function (Obj) {
                Obj.touchable = false;
              });
            }
            settingObj.forEach(function (Obj) {
              Obj.modified();
            });
            startObj.forEach(function (Obj) {
              Obj.modified();
            });
            settingstrs.forEach(function (Obj) {
              Obj.invalidate();
            });
          });

          ///////////////////
          ////タイトル画面////
          ///////////////////
          var background = new g.FrameSprite({
            scene: scene,
            src: scene.assets["haikei"],
            parent: backlayer,
            opacity: 0.5,
            touchable: false
          });
          var title_Image = new g.FrameSprite({
            scene: scene,
            x: g.game.width * 0.05,
            y: g.game.height * 0.02,
            src: scene.assets["title"],
            parent: backlayer,
            opacity: 1,
            touchable: false
          });
          scene.append(title_Image);
          var rule_Image = new g.FrameSprite({
            scene: scene,
            x: g.game.width * 0.24,
            y: g.game.height * 0.65,
            src: scene.assets["rule"],
            parent: backlayer,
            opacity: 1,
            touchable: false
          });
          scene.append(rule_Image);
          titleObj = [title_Image, rule_Image];

          /////////////////
          ////参加ボタン////
          /////////////////
          var sankaBack = new g.FilledRect({
            scene: scene,
            x: g.game.width * 0.9 - 10,
            y: g.game.height * 0.9,
            width: 120,
            height: 60,
            cssColor: "black",
            opacity: 0.3,
            touchable: true,
            local: true
          });
          scene.append(sankaBack);
          var sankaButton = new g.Label({
            scene: scene,
            x: g.game.width * 0.9,
            y: g.game.height * 0.9,
            font: font,
            text: "参加",
            fontSize: 50,
            textColor: "black",
            opacity: 1,
            parent: buttonlayer,
            local: true
          });
          scene.append(sankaButton);
          sankaBack.onPointDown.add(function () {
            resolvePlayerInfo.resolvePlayerInfo({
              raises: true
            });
            sankaObj.forEach(function (Obj) {
              Obj.touchable = false;
              Obj.hide();
            });
          });
          sankaObj = [sankaBack, sankaButton];

          ///////////////////////////////////////
          ////操作キャラ生成・プレイヤー情報記録////
          ///////////////////////////////////////
          g.game.onPlayerInfo.add(function (ev) {
            // 各プレイヤーが名前利用許諾のダイアログに応答した時、通知されます。
            // ev.player.name にそのプレイヤーの名前が含まれます。
            // (ev.player.id には (最初から) プレイヤーIDが含まれています)

            var isLocalPlayer = ev.player.id === g.game.selfId;
            var Nushi_Then = ev.player.id === broadcasterPlayerId;

            // プレイヤー画像
            var imageOk = scene.assets[isLocalPlayer ? "Main_OK" : Nushi_Then ? "Nushi_OK" : "NPC_OK"];
            var imageNg = scene.assets[isLocalPlayer ? "Main_botti" : Nushi_Then ? "Nushi_botti" : "NPC_botti"];
            PlayerIds.push(ev.player.id);
            var playerImage = new g.FrameSprite({
              scene: scene,
              src: imageNg,
              x: getrandom(20, 1250, -1),
              y: getrandom(y_limit, 680, -1),
              opacity: 1,
              local: false,
              hidden: true
            });
            scene.append(playerImage);
            playerImage.invalidate();
            PlayerDatas[ev.player.id] = {
              Name: ev.player.name,
              Main_Player: playerImage,
              moveX: 0,
              moveY: 0,
              imageD: 0,
              sotuThen: false,
              destoroyed: false,
              imageOk: imageOk,
              imageNg: imageNg
            };
            playercntLabel.text = String(PlayerIds.length) + "人", playercntLabel.invalidate();
            settingstrs.forEach(function (Obj) {
              Obj.invalidate();
            });
          });

          ////////////////////////////
          ////プレイヤー人数カウント////
          ////////////////////////////
          var playercntBack = new g.FilledRect({
            scene: scene,
            x: g.game.width * 0.73,
            y: g.game.height / 5,
            width: 300,
            height: 300,
            cssColor: "gray",
            opacity: 0.5,
            parent: backlayer,
            touchable: false
          });
          scene.append(playercntBack);
          var playercntLabel = new g.Label({
            scene: scene,
            x: g.game.width * 0.8,
            y: g.game.height / 2.65,
            font: font,
            text: 1 + "人",
            fontSize: 75,
            textColor: "black",
            touchable: false,
            opacity: 1,
            local: false
          });
          scene.append(playercntLabel);
          var playercntHedder = new g.Label({
            scene: scene,
            x: g.game.width * 0.77,
            y: g.game.height / 4,
            font: font,
            text: "参加人数",
            fontSize: 50,
            textColor: "black",
            touchable: false,
            opacity: 1
          });
          scene.append(playercntHedder);
          playercntObj = [playercntBack, playercntHedder, playercntLabel];

          /////////////////
          ////開始ボタン////
          /////////////////
          var startBack = new g.FilledRect({
            scene: scene,
            x: g.game.width * 0.1 - 10,
            y: g.game.height * 0.9,
            width: 215,
            height: 60,
            cssColor: "gray",
            opacity: 0.3,
            touchable: false,
            local: true
          });
          scene.append(startBack);
          var startButton = new g.Label({
            scene: scene,
            x: g.game.width * 0.1,
            y: g.game.height * 0.9,
            font: font,
            text: "締め切る",
            fontSize: 50,
            textColor: "black",
            parent: buttonlayer,
            local: true
          });
          scene.append(startButton);
          startBack.onPointDown.add(function () {
            g.game.raiseEvent(new g.MessageEvent({
              message: "GameStart"
            }));
          });
          startObj = [startBack, startButton];

          ///////////////////
          ////制限時間設定////
          ///////////////////
          //制限時間設定用背景
          var gamesecondBack = new g.FilledRect({
            scene: scene,
            x: g.game.width * 0.05,
            y: g.game.height / 5,
            width: 760,
            height: 300,
            cssColor: "gray",
            opacity: 0.5,
            parent: backlayer,
            touchable: false,
            local: false
          });
          scene.append(gamesecondBack);

          // 残り時間表示用ラベル
          var timeLabel = new g.Label({
            scene: scene,
            x: g.game.width * 0.05,
            font: font,
            text: "60",
            hidden: true,
            fontSize: 50,
            textColor: "black",
            touchable: false,
            opacity: 1,
            parent: buttonlayer,
            local: false
          });
          scene.append(timeLabel);

          //秒ボタン
          //+1
          var oneplusBack = new g.FilledRect({
            scene: scene,
            x: g.game.width * 0.55,
            y: g.game.height / 2.5,
            width: 100,
            height: 60,
            cssColor: "black",
            opacity: 0.3,
            parent: buttonlayer,
            local: false
          });
          scene.append(oneplusBack);
          oneplusBack.onPointDown.add(function () {
            g.game.raiseEvent(new g.MessageEvent({
              message: "secondUpdate",
              PulsSecond: 1
            }));
          });
          var oneplusButton = new g.Label({
            scene: scene,
            x: g.game.width * 0.56,
            y: g.game.height / 2.5,
            font: font,
            text: "+１",
            fontSize: 50,
            textColor: "black",
            touchable: false,
            opacity: 1,
            parent: buttonlayer,
            local: false
          });
          scene.append(oneplusButton);

          //+10
          var tenplusBack = new g.FilledRect({
            scene: scene,
            x: g.game.width * 0.44,
            y: g.game.height / 2.5,
            width: 120,
            height: 60,
            cssColor: "black",
            opacity: 0.3,
            parent: buttonlayer,
            local: false
          });
          scene.append(tenplusBack);
          tenplusBack.onPointDown.add(function () {
            g.game.raiseEvent(new g.MessageEvent({
              message: "secondUpdate",
              PulsSecond: 10
            }));
          });
          var tenplusButton = new g.Label({
            scene: scene,
            x: g.game.width * 0.445,
            y: g.game.height / 2.5,
            font: font,
            text: "+10",
            fontSize: 50,
            textColor: "black",
            touchable: false,
            opacity: 1,
            parent: buttonlayer,
            local: false
          });
          scene.append(tenplusButton);

          //-1
          var onepullBack = new g.FilledRect({
            scene: scene,
            x: g.game.width * 0.07,
            y: g.game.height / 2.5,
            width: 95,
            height: 60,
            cssColor: "black",
            opacity: 0.3,
            parent: buttonlayer,
            local: false
          });
          scene.append(onepullBack);
          onepullBack.onPointDown.add(function () {
            g.game.raiseEvent(new g.MessageEvent({
              message: "secondUpdate",
              PulsSecond: -1
            }));
          });
          var onepullButton = new g.Label({
            scene: scene,
            x: g.game.width * 0.085,
            y: g.game.height / 2.5,
            font: font,
            text: "-１",
            fontSize: 50,
            textColor: "black",
            touchable: false,
            opacity: 1,
            parent: buttonlayer,
            local: false
          });
          scene.append(onepullButton);

          //-10
          var tenpullBack = new g.FilledRect({
            scene: scene,
            x: g.game.width * 0.16,
            y: g.game.height / 2.5,
            width: 110,
            height: 60,
            cssColor: "black",
            opacity: 0.3,
            parent: buttonlayer,
            touchable: true,
            local: false
          });
          scene.append(tenpullBack);
          tenpullBack.onPointDown.add(function () {
            g.game.raiseEvent(new g.MessageEvent({
              message: "secondUpdate",
              PulsSecond: -10
            }));
          });
          var tenpullButton = new g.Label({
            scene: scene,
            x: g.game.width * 0.17,
            y: g.game.height / 2.5,
            font: font,
            text: "-10",
            fontSize: 50,
            textColor: "black",
            touchable: false,
            opacity: 1,
            parent: buttonlayer,
            local: false
          });
          scene.append(tenpullButton);

          //秒ラベル
          var gamesecondLabel = new g.Label({
            scene: scene,
            x: g.game.width * 0.28,
            y: g.game.height / 2.65,
            font: font,
            text: gamesecond + "秒",
            fontSize: 75,
            textColor: "black",
            touchable: false,
            opacity: 1,
            local: false
          });
          scene.append(gamesecondLabel);
          var gamesecondHedder = new g.Label({
            scene: scene,
            x: g.game.width * 0.26,
            y: g.game.height / 4,
            font: font,
            text: "制限時間",
            fontSize: 50,
            textColor: "black",
            touchable: false,
            opacity: 1,
            local: false
          });
          scene.append(gamesecondHedder);

          //一括処理したいので配列に放り込む
          settingObj = [startBack, oneplusBack, onepullBack, tenplusBack, tenpullBack, gamesecondBack, gamesecondHedder];
          settingstrs = [startButton, oneplusButton, onepullButton, tenplusButton, tenpullButton, gamesecondLabel];

          ///////////////////
          ////クリック処理////
          ///////////////////
          scene.onPointDownCapture.add(function (ev) {
            if (gameNowThen == true) {
              //クリックした位置に移動
              if (PlayerIds.indexOf(ev.player.id) != -1) {
                //枠外飛び出し防止処理
                var NextX = ev.point.x - 22.5;
                if (NextX < 1) {
                  NextX = 1;
                } else if (NextX > 1240) {
                  NextX = 1240;
                }
                var NextY = ev.point.y - 29.5;
                if (NextY < y_limit) {
                  NextY = y_limit;
                } else if (NextY > 670) {
                  NextY = 670;
                }

                //斜辺を求める(速度を一定にしたいので)
                var imageD = Math.abs(Math.sqrt(Math.pow(Math.abs(PlayerDatas[ev.player.id].Main_Player.x - NextX), 2) + Math.pow(Math.abs(PlayerDatas[ev.player.id].Main_Player.y - NextY), 2)));

                //移動処理
                timeline.create(PlayerDatas[ev.player.id].Main_Player).moveTo(NextX, NextY, imageD * 5);
              }
            }
          });

          /////////////////////////
          ////卒業(退学)リスト用////
          /////////////////////////
          var backLabel = new g.FilledRect({
            scene: scene,
            hidden: true,
            width: g.game.width,
            height: g.game.height,
            cssColor: "black",
            opacity: 1
          });
          scene.append(backLabel);
          var strLabel = new g.Label({
            scene: scene,
            x: g.game.width / 2.4,
            y: 20,
            font: font,
            text: "卒業",
            fontSize: 50,
            textColor: "white",
            opacity: 1,
            touchable: true,
            hidden: true
          });
          scene.append(strLabel);

          ////////////////////////////
          ////オブジェクト初期化処理////
          ////////////////////////////
          titleObj.forEach(function (Obj) {
            Obj.modified();
          });
          settingObj.forEach(function (Obj) {
            Obj.modified();
          });
          settingstrs.forEach(function (Obj) {
            Obj.modified();
          });
          startObj.forEach(function (Obj) {
            Obj.modified();
          });
          sankaObj.forEach(function (Obj) {
            Obj.modified();
          });
          playercntObj.forEach(function (Obj) {
            Obj.modified();
          });
          background.invalidate();
          backLabel.modified();

          /////////////////////
          ////グローバル処理////
          /////////////////////
          scene.message.add(function (ev) {
            switch (ev.data.message) {
              case "GameStart":
                timeLabel.text = String(gamesecond);
                timeLabel.show();
                timeLabel.invalidate();
                startThen = true;
                break;
              case "secondUpdate":
                //制限時間設定を全体に反映
                gamesecond += ev.data.PulsSecond;
                if (gamesecond < 1) {
                  gamesecond = 1;
                } else if (gamesecond > 60) {
                  gamesecond = 60;
                }
                gamesecondLabel.text = gamesecond + "秒";
                gamesecondLabel.invalidate();
                break;
              case "Sotugyo_Hantei":
                PlayerIds.forEach(function (Id) {
                  //卒業判定
                  var result = false;
                  var zyuhukuIds = [];
                  //重複しているキャラを探索
                  PlayerIds.forEach(function (Id2) {
                    if (Id != Id2) {
                      var x1 = PlayerDatas[Id].Main_Player.x;
                      var x2 = PlayerDatas[Id2].Main_Player.x;
                      var y1 = PlayerDatas[Id].Main_Player.y;
                      var y2 = PlayerDatas[Id2].Main_Player.y;
                      if (Math.abs(x1 - x2) < overlap_threshold && Math.abs(y1 - y2) < overlap_threshold) {
                        zyuhukuIds.push(Id2);
                      }
                    }
                  });
                  if (zyuhukuIds == []) {
                    //重複無し(ぼっち)なら退学
                    result = false;
                  } else if (zyuhukuIds.length == 1) {
                    //重複が一人なら一旦卒業扱い
                    result = true;

                    //ペア側の重複キャラを探索
                    PlayerIds.forEach(function (Id2) {
                      if (zyuhukuIds[0] != Id && zyuhukuIds[0] != Id2 && Id != Id2) {
                        var x1 = PlayerDatas[zyuhukuIds[0]].Main_Player.x;
                        var x2 = PlayerDatas[Id2].Main_Player.x;
                        var y1 = PlayerDatas[zyuhukuIds[0]].Main_Player.y;
                        var y2 = PlayerDatas[Id2].Main_Player.y;
                        if (Math.abs(x1 - x2) < overlap_threshold && Math.abs(y1 - y2) < overlap_threshold) {
                          //ペア側に別の重複キャラがいるなら２人組では無いので退学
                          result = false;
                        }
                      }
                    });
                  } else {
                    //重複が２人以上なら２人組では無いので退学
                    result = false;
                  }
                  //プレイヤー画像更新
                  PlayerDatas[Id].sotuThen = result;
                  PlayerDatas[Id].Main_Player.src = result ? PlayerDatas[Id].imageOk : PlayerDatas[Id].imageNg;
                  PlayerDatas[Id].Main_Player.invalidate();
                });
              default:
                break;
            }
          });

          /////////////////
          ////ゲーム動作////
          /////////////////
          scene.onUpdate.add(function () {
            if (startThen == true) {
              //開始処理
              //タイトル・設定項目削除
              titleObj.forEach(function (Obj) {
                Obj.touchable = false;
                Obj.hide();
              });
              settingObj.forEach(function (Obj) {
                Obj.touchable = false;
                Obj.hide();
              });
              settingstrs.forEach(function (Obj) {
                Obj.touchable = false;
                Obj.hide();
              });
              startObj.forEach(function (Obj) {
                Obj.touchable = false;
                Obj.hide();
              });
              sankaObj.forEach(function (Obj) {
                Obj.touchable = false;
                Obj.hide();
              });
              playercntObj.forEach(function (Obj) {
                Obj.touchable = false;
                Obj.hide();
              });
              title_Image.hide();

              //半透明にしていた背景を非透明化
              background.opacity = 1;
              background.invalidate();

              //プレイヤーオブジェクト生成
              PlayerIds.forEach(function (Id) {
                PlayerDatas[Id].Main_Player.invalidate();
                PlayerDatas[Id].Main_Player.show();
              });
              startThen = false;
              gameNowThen = true;
            }
            if (gameNowThen == true) {
              //ゲームメイン処理
              gametime += 1 / g.game.fps;
              if (gamesecond - gametime > 0) {
                //卒業判定
                g.game.raiseEvent(new g.MessageEvent({
                  message: "Sotugyo_Hantei"
                }));
                timeLabel.text = String(Math.ceil(gamesecond - gametime));
                timeLabel.invalidate();
              } else {
                //タイムアップ(gametimeが０以下になれば)したらこちらに遷移
                gameNowThen = false;
                gameendThen = true;

                //bgm停止
                bgm1.stop();

                //背景・タイマー削除
                background.hide();
                timeLabel.hide();
                var sotugyoY = 0;
                var taigakuY = 0;
                PlayerIds.forEach(function (Id) {
                  //プレイヤーオブジェクト削除
                  PlayerDatas[Id].Main_Player.hide();

                  //卒業・退学リスト作成
                  if (PlayerDatas[Id].sotuThen == true) {
                    sotugyolabels.push(user_add(scene, PlayerDatas[Id].Name, sotugyoY));
                    sotugyoY += 60;
                  } else {
                    taigakulabels.push(user_add(scene, PlayerDatas[Id].Name, taigakuY));
                    taigakuY += 60;
                  }
                });

                //卒業・退学リスト用背景・ヘッダー生成
                backLabel.show();
                strLabel.show();
                strLabel.invalidate();

                //卒業用のBGMを流す
                bgm2 = scene.asset.getAudio("/audio/hotaru_piano_5").play().changeVolume(0.1);
              }
            }
            if (gameendThen == true) {
              //卒業・退学一覧処理
              var sotuNow = true;
              var taiNow = false;
              var endThen = false;

              //卒業
              if (sotugyolabels.length > 0) {
                if (sotuNow == true) {
                  sotugyolabels = userList_show(sotugyolabels);
                  if (showEnd_Then(sotugyolabels) == true) {
                    sotuNow = false;
                    taiNow = true;
                  }
                }
              } else {
                sotuNow = false;
                taiNow = true;
              }

              //退学
              if (taigakulabels.length > 0) {
                if (taiNow == true) {
                  strLabel.text = "退学";
                  strLabel.invalidate();
                  taigakulabels = userList_show(taigakulabels);
                  if (showEnd_Then(taigakulabels) == true) {
                    taiNow = false;
                    endThen = true;
                  }
                }
              } else if (sotuNow == false) {
                taiNow = false;
                endThen = true;
              }

              //最終処理に遷移(オブジェクト削除)
              if (endThen == true) {
                gameendThen = false;
                strLabel.hide();
                backLabel.hide();
                sotugyoThen = true;
              }
            }
            if (sotugyoThen == true) {
              //最終処理
              var sotugyo_Obj = [];
              if (PlayerDatas[broadcasterPlayerId].sotuThen == true) {
                //放送主が卒業時
                var sotugyo_Image = new g.FrameSprite({
                  scene: scene,
                  src: scene.assets["sotugyo"],
                  parent: backlayer,
                  opacity: 1,
                  touchable: false
                });
                sotugyo_Obj.push(sotugyo_Image);
              } else {
                //放送主が退学時
                var newsX = g.game.width * 0.1;
                //容疑者
                var suspect_Label = new g.FilledRect({
                  scene: scene,
                  width: 800,
                  height: 70,
                  cssColor: "red",
                  opacity: 7,
                  x: newsX,
                  y: g.game.height - 210
                });
                sotugyo_Obj.push(suspect_Label);
                var suspect_text = new g.Label({
                  scene: scene,
                  x: newsX,
                  y: g.game.height - 210,
                  font: font,
                  text: " " + PlayerDatas[broadcasterPlayerId].Name + "容疑者(12)",
                  fontSize: 50,
                  textColor: "white",
                  opacity: 1,
                  touchable: false
                });
                sotugyo_Obj.push(suspect_text);

                //ニュース本文
                var Main_Label = new g.FilledRect({
                  scene: scene,
                  width: 1000,
                  height: 125,
                  cssColor: "black",
                  opacity: 0.5,
                  x: newsX,
                  y: g.game.height - 140
                });
                sotugyo_Obj.push(Main_Label);
                var Main_text1 = new g.Label({
                  scene: scene,
                  x: newsX,
                  y: g.game.height - 140,
                  font: font,
                  text: "「２人組が作れないから退学させられた」",
                  fontSize: 50,
                  textColor: "white",
                  opacity: 1,
                  touchable: false
                });
                sotugyo_Obj.push(Main_text1);
                var Main_text2 = new g.Label({
                  scene: scene,
                  x: newsX,
                  y: g.game.height - 80,
                  font: font,
                  text: " などと訳の分からない供述を続けている",
                  fontSize: 50,
                  textColor: "white",
                  opacity: 1,
                  touchable: false
                });
                sotugyo_Obj.push(Main_text2);

                //ニュースヘッダー画像
                var heddar_Image = new g.FrameSprite({
                  scene: scene,
                  src: scene.assets["taiho"],
                  parent: backlayer,
                  opacity: 1,
                  touchable: false,
                  x: g.game.width * 0.7,
                  y: g.game.height * 0.01
                });
                sotugyo_Obj.push(heddar_Image);
              }

              //オブジェクト生成
              sotugyo_Obj.forEach(function (Obj) {
                scene.append(Obj);
                Obj.modified();
              });
              sotugyoThen = false;
            }
          });
        });
        g.game.pushScene(scene);
      }
      ;
      module.exports = main;

      //乱数生成機
      function getrandom(min, max, exc) {
        var int = g.game.random.get(min, max);
        while (exc != -1 && exc == int) {
          int = g.game.random.get(min, max);
        }
        return int;
      }
      ;

      //卒業(退学)リスト作成用
      function user_add(scene, Nametxt, plusY) {
        var userLabel = new g.Label({
          scene: scene,
          x: g.game.width * 0.1 + (33 - Nametxt.bytes()) * 0.5 * 29,
          y: g.game.height + plusY,
          font: font,
          text: Nametxt,
          fontSize: 50,
          textColor: "white",
          opacity: 1,
          touchable: false,
          hidden: true
        });
        scene.append(userLabel);
        userLabel.invalidate();
        return userLabel;
      }
      String.prototype.bytes = function () {
        var length = 0;
        for (var i = 0; i < this.length; i++) {
          var c = this.charCodeAt(i);
          if (c >= 0x0 && c < 0x81 || c === 0xf8f0 || c >= 0xff61 && c < 0xffa0 || c >= 0xf8f1 && c < 0xf8f4) {
            length += 1;
          } else {
            length += 2;
          }
        }
        return length;
      };
      function userList_show(labels) {
        var labelwait = 15 / labels.length;
        labels.forEach(function (label) {
          if (label.y < 70) {
            label.hide();
          } else if (label.y <= g.game.height) {
            label.show();
          }
          label.y -= labelwait;
          label.invalidate();
        });
        return labels;
      }
      function showEnd_Then(labels) {
        var result = true;
        labels.forEach(function (label) {
          if (label.visible() == true) {
            result = false;
          }
        });
        return result;
      }
    }, {
      "@akashic-extension/akashic-timeline": 8,
      "@akashic-extension/resolve-player-info": 10
    }]
  }, {}, [11])(11);
});